Pre requisits to compile
---------------------------------------
1. Android SDK.
2. Eclipse Android Developer
3. .NET Framework 4 or higher.
4. Visual Studio 2012. 

Details PROJECT folder
---------------------------------------
1. The PROJECT folder contains two sub folders named CLIENT_PROJECT and SERVER_PROJECT.
2. CLIENT_PROJECT folder contains simply configurable project files so that it can be imported easily to the Eclipse Android Developer IDE. 
3. SERVER_PROJECT contains project files those can be easily loaded to the Visual Studio 2012 IDE.

Details SOURCE_FILES folder
---------------------------------------
1. The SOURCE_FILES folder contains two sub folders named CLIENT_SOURCE and SERVER_SOURCE
2. CLIENT_SOURCE folder contains relavant source files regarding the Android client application. (Please note that we have extended a sample application developed by google as a sample to bluetooth communication for our client application.)
3. SERVER_SOURCE folder contains relavent source files for the server application.
