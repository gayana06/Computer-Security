/*
 * Copyright (C) 2009 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.example.btcrypt;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.GeneralSecurityException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.KeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import com.example.justtest.R;

import android.R.string;
import android.app.ActionBar;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.opengl.Visibility;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Base64;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.view.inputmethod.EditorInfo;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

/**
 * This is the main Activity that displays the current chat session.
 */
public class BtCrypt extends Activity  {
    // Debugging
    private static final String TAG = "BluetoothChat";
    private static final boolean D = true;

    // Message types sent from the BluetoothChatService Handler
    public static final int MESSAGE_STATE_CHANGE = 1;
    public static final int MESSAGE_READ = 2;
    public static final int MESSAGE_WRITE = 3;
    public static final int MESSAGE_DEVICE_NAME = 4;
    public static final int MESSAGE_TOAST = 5;

    // Key names received from the BluetoothChatService Handler
    public static final String DEVICE_NAME = "device_name";
    public static final String TOAST = "toast";

    // Intent request codes
    private static final int REQUEST_CONNECT_DEVICE_SECURE = 1;
    private static final int REQUEST_CONNECT_DEVICE_INSECURE = 2;
    private static final int REQUEST_ENABLE_BT = 3;

    // Layout Views
    private ListView mConversationView;
    private EditText mOutEditText;
    private Button mSendButton;
    
    /*Additional Code by Group 07 */
    
    private Button mConnect;
    private Button mDisconnect;
    private String passwordHash;
    TextView viewuname;
    TextView viewpwd;
    private String sessionKey;
	private final String characterEncoding = "UTF-8";
    private final String cipherTransformation = "AES/CBC/PKCS5Padding";
    private final String aesEncryptionAlgorithm = "AES";
    private final String MSG_USERNAME="UN";
    private final String MSG_SEP_COLON=":";
    private final String MSG_AUTHENTICATED="ATD";
    private final String MSG_CHALLENGE="CH";
    private final String MSG_CHALLENGE_REPLY="CHR";
    private final String MSG_SESSION_KEY_GET="GSK";
    private final String MSG_SESSION_KEY_REPLY="RSK";
    
    // Name of the connected device
    private String mConnectedDeviceName = null;
    // Array adapter for the conversation thread
    private ArrayAdapter<String> mConversationArrayAdapter;
    // String buffer for outgoing messages
    private StringBuffer mOutStringBuffer;
    // Local Bluetooth adapter
    private BluetoothAdapter mBluetoothAdapter = null;
    // Member object for the chat services
    private BtCryptServices mChatService = null;
    

    
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if(D) Log.e(TAG, "+++ ON CREATE +++");

        // Set up the window layout
        setContentView(R.layout.activity_main);

        // Get local Bluetooth adapter
        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

        // If the adapter is null, then Bluetooth is not supported
        if (mBluetoothAdapter == null) {
            Toast.makeText(this, "Bluetooth is not available", Toast.LENGTH_LONG).show();
            finish();
            return;
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        if(D) Log.e(TAG, "++ ON START ++");

        // If BT is not on, request that it be enabled.
        // setupChat() will then be called during onActivityResult
        if (!mBluetoothAdapter.isEnabled()) {
            Intent enableIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableIntent, REQUEST_ENABLE_BT);
        // Otherwise, setup the chat session
        } else {
            if (mChatService == null) setupChat();
        }
    }

    @Override
    public synchronized void onResume() {
        super.onResume();
        if(D) Log.e(TAG, "+ ON RESUME +");

        // Performing this check in onResume() covers the case in which BT was
        // not enabled during onStart(), so we were paused to enable it...
        // onResume() will be called when ACTION_REQUEST_ENABLE activity returns.
        if (mChatService != null) {
            // Only if the state is STATE_NONE, do we know that we haven't started already
            if (mChatService.getState() == BtCryptServices.STATE_NONE) {
              // Start the Bluetooth chat services
              mChatService.start();
            }
        }
    }
    

    
    private void setupChat() {
        Log.d(TAG, "setupChat()");

        // Initialize the array adapter for the conversation thread
        mConversationArrayAdapter = new ArrayAdapter<String>(this, R.layout.message);
        mConversationView = (ListView) findViewById(R.id.in);
        mConversationView.setAdapter(mConversationArrayAdapter);
        
              

        // Initialize the compose field with a listener for the return key
        mOutEditText = (EditText) findViewById(R.id.edit_text_out);
        mOutEditText.setOnEditorActionListener(mWriteListener);

        // Initialize the send button with a listener that for click events
        mSendButton = (Button) findViewById(R.id.button_send);
        mSendButton.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                // Send a message using content of the edit text widget
                TextView view = (TextView) findViewById(R.id.edit_text_out);
                String message = view.getText().toString();
                sendMessage(message);
            }
        });
        
        /*Additional Code by Group 07 */
        
        mOutEditText.setVisibility(View.GONE);
        mSendButton.setVisibility(View.GONE);
        mConversationView.setVisibility(View.GONE);
        mConnect=(Button)findViewById(R.id.button_connect);
        mConnect.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                // Send a message using content of the edit text widget
            	Connect();
            }
        });
        mDisconnect=(Button)findViewById(R.id.button_disconnect);
        mDisconnect.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                // Send a message using content of the edit text widget                
               Disconnect();
            }
        });
        mConnect.setVisibility(View.VISIBLE);
        mDisconnect.setVisibility(View.GONE);
        
        
        // Initialize the BluetoothChatService to perform bluetooth connections
        mChatService = new BtCryptServices(this, mHandler);

        // Initialize the buffer for outgoing messages
        mOutStringBuffer = new StringBuffer("");
        viewuname = (TextView) findViewById(R.id.edit_username);
        viewpwd = (TextView) findViewById(R.id.edit_password);

    }
    


    @Override
    public synchronized void onPause() {
        super.onPause();
        if(D) Log.e(TAG, "- ON PAUSE -");
    }

    @Override
    public void onStop() {
        super.onStop();
        if(D) Log.e(TAG, "-- ON STOP --");
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        // Stop the Bluetooth chat services
        if (mChatService != null) mChatService.stop();
        if(D) Log.e(TAG, "--- ON DESTROY ---");
    }

    private void ensureDiscoverable() {
        if(D) Log.d(TAG, "ensure discoverable");
        if (mBluetoothAdapter.getScanMode() !=
            BluetoothAdapter.SCAN_MODE_CONNECTABLE_DISCOVERABLE) {
            Intent discoverableIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
            discoverableIntent.putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 300);
            startActivity(discoverableIntent);
        }
    }

    /**
     * Sends a message.
     * @param message  A string of text to send.
     */
    private  void sendMessage(String message) {
        // Check that we're actually connected before trying anything
        if (mChatService.getState() != BtCryptServices.STATE_CONNECTED) {
            Toast.makeText(this, R.string.not_connected, Toast.LENGTH_SHORT).show();
            return;
        }

        // Check that there's actually something to send
        if (message.length() > 0) {
            // Get the message bytes and tell the BluetoothChatService to write
            byte[] send = message.getBytes();
            mChatService.write(send);

            // Reset out string buffer to zero and clear the edit text field
            mOutStringBuffer.setLength(0);
            mOutEditText.setText(mOutStringBuffer);
        }
    }
    


    // The action listener for the EditText widget, to listen for the return key
    private TextView.OnEditorActionListener mWriteListener =
        new TextView.OnEditorActionListener() {
        public boolean onEditorAction(TextView view, int actionId, KeyEvent event) {
            // If the action is a key-up event on the return key, send the message
            if (actionId == EditorInfo.IME_NULL && event.getAction() == KeyEvent.ACTION_UP) {
	            	String message = view.getText().toString();
	                sendMessage(message);
            }
            if(D) Log.i(TAG, "END onEditorAction");
            return true;
        }
    };

    private final void setStatus(int resId) {
        final ActionBar actionBar = getActionBar();
        actionBar.setSubtitle(resId);
    }

    private final void setStatus(CharSequence subTitle) {
        final ActionBar actionBar = getActionBar();
        actionBar.setSubtitle(subTitle);
    }

    // The Handler that gets information back from the BluetoothChatService
    private final Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
            case MESSAGE_STATE_CHANGE:
                if(D) Log.i(TAG, "MESSAGE_STATE_CHANGE: " + msg.arg1);
                switch (msg.arg1) {
                case BtCryptServices.STATE_CONNECTED:
                    setStatus(getString(R.string.title_connected_to, mConnectedDeviceName));
                    mConversationArrayAdapter.clear();
                    break;
                case BtCryptServices.STATE_CONNECTING:
                    setStatus(R.string.title_connecting);
                    break;
                case BtCryptServices.STATE_LISTEN:
                case BtCryptServices.STATE_NONE:
                    setStatus(R.string.title_not_connected);   
                    SetInitialDisplay();
                    break;
                }
                break;
            case MESSAGE_WRITE:
                byte[] writeBuf = (byte[]) msg.obj;
                // construct a string from the buffer
                String writeMessage = new String(writeBuf);
                mConversationArrayAdapter.add("Me:  " + writeMessage);
                
                break;
            case MESSAGE_READ:
                byte[] readBuf = (byte[]) msg.obj;
                // construct a string from the valid bytes in the buffer
                String readMessage = new String(readBuf, 0, msg.arg1);
                mConversationArrayAdapter.add(mConnectedDeviceName+":  " + readMessage);  
                ProcessServerCall(readMessage);
                break;
            case MESSAGE_DEVICE_NAME:
                // save the connected device's name
                mConnectedDeviceName = msg.getData().getString(DEVICE_NAME);
                Toast.makeText(getApplicationContext(), "Connected to "
                               + mConnectedDeviceName, Toast.LENGTH_SHORT).show();
                break;
            case MESSAGE_TOAST:
                Toast.makeText(getApplicationContext(), msg.getData().getString(TOAST),
                               Toast.LENGTH_SHORT).show();
                break;
            }
        }
    };

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(D) Log.d(TAG, "onActivityResult " + resultCode);
        switch (requestCode) {
        case REQUEST_CONNECT_DEVICE_SECURE:
            // When DeviceListActivity returns with a device to connect
            if (resultCode == Activity.RESULT_OK) {
                connectDevice(data, true);
            }
            break;
        case REQUEST_CONNECT_DEVICE_INSECURE:
            // When DeviceListActivity returns with a device to connect
            if (resultCode == Activity.RESULT_OK) {
                connectDevice(data, false);
            }
            break;
        case REQUEST_ENABLE_BT:
            // When the request to enable Bluetooth returns
            if (resultCode == Activity.RESULT_OK) {
                // Bluetooth is now enabled, so set up a chat session
                setupChat();
            } else {
                // User did not enable Bluetooth or an error occurred
                Log.d(TAG, "BT not enabled");
                Toast.makeText(this, R.string.bt_not_enabled_leaving, Toast.LENGTH_SHORT).show();
                finish();
            }
        }
    }

    private void connectDevice(Intent data, boolean secure) {
        // Get the device MAC address
        String address = data.getExtras()
            .getString(DeviceListActivity.EXTRA_DEVICE_ADDRESS);
        // Get the BluetoothDevice object
        BluetoothDevice device = mBluetoothAdapter.getRemoteDevice(address);
        // Attempt to connect to the device
        mChatService.connect(device, secure);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.option_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent serverIntent = null;
        switch (item.getItemId()) {
        case R.id.secure_connect_scan:
            // Launch the DeviceListActivity to see devices and do scan
            serverIntent = new Intent(this, DeviceListActivity.class);
            startActivityForResult(serverIntent, REQUEST_CONNECT_DEVICE_SECURE);
            return true;
        case R.id.insecure_connect_scan:
            // Launch the DeviceListActivity to see devices and do scan
            serverIntent = new Intent(this, DeviceListActivity.class);
            startActivityForResult(serverIntent, REQUEST_CONNECT_DEVICE_INSECURE);
            return true;
        case R.id.discoverable:
            // Ensure this device is discoverable by others
            ensureDiscoverable();
            return true;
        }
        return false;
    }
    
    /*Additional Code by Group 07 */
    
    //Check the connection is alive
    private Boolean IsConnectedToServer()
    {    
    	Boolean isConnected=false;
    	if (mChatService.getState() == BtCryptServices.STATE_CONNECTED)
    	{
    		isConnected=true;
    	} 
    	return isConnected;
    }
    
    //Start communication with server
    private void Connect()
    {
    	try
    	{
	    	if(IsConnectedToServer())
	    	{
	    		sessionKey=null;
		        String username = viewuname.getText().toString();                
		        String password = viewpwd.getText().toString();
		        passwordHash= GetSHAHash(password);
		        //String encryptedText=encrypt(MSG_USERNAME+MSG_SEP_COLON+ username, passwordHash);
		        String initialMsg=MSG_USERNAME+MSG_SEP_COLON+ username;
		        sendMessage(initialMsg);		        
		        viewuname.setEnabled(false);
		        viewpwd.setEnabled(false);
		        mConnect.setVisibility(View.GONE);
		        mDisconnect.setVisibility(View.VISIBLE);		        
		        
	    	}
	    	else
	    	{
	    		 Toast.makeText(this, R.string.not_connected, Toast.LENGTH_SHORT).show();
	    		 UpdateMessage("Device not connected");
	    	}
    	}
    	catch(Exception ex)
    	{
    		System.err.println(ex.getMessage());
    	}
        
    }
    
    //Disconnect the socket connection
    private void Disconnect()
    {
    	try
    	{
	    	if(mChatService!=null)
	    		mChatService.stop();
	    	SetInitialDisplay();
    	}
    	catch(Exception ex)
    	{
    		Toast.makeText(this, ex.getMessage(), Toast.LENGTH_SHORT).show();
    	}
    }
    
    //Set front end at initial load
    private void SetInitialDisplay()
    {
        mConnect.setVisibility(View.VISIBLE);
        mDisconnect.setVisibility(View.GONE);
        viewuname.setEnabled(true);
        viewuname.setText("");
        viewpwd.setEnabled(true);
        viewpwd.setText("");
        UpdateMessage("Please start a new session");
    }
    
    //Process messages from the servers
    public  void ProcessServerCall(String message)
    {
    	try
    	{
	    	if(IsConnectedToServer() && message.length() > 0)
	    	{
	    		String decryptedMsg;
	    		if(sessionKey!=null && sessionKey!="")
	    			decryptedMsg=decrypt(message, sessionKey);
	    		else
	    			decryptedMsg=decrypt(message, passwordHash);
	    		System.out.println("DECRYPTED MSG - "+decryptedMsg);
	    		if(decryptedMsg.startsWith(MSG_SESSION_KEY_GET+MSG_SEP_COLON))
	    		{
	    			ProcessSessionKey(decryptedMsg.split(MSG_SEP_COLON)[1],decryptedMsg.split(MSG_SEP_COLON)[2]);
	    			UpdateMessage("Authenticating....");
	    		}
	    		else if(decryptedMsg.startsWith(MSG_AUTHENTICATED+MSG_SEP_COLON))
	    		{
	    			UpdateMessage("Successfully Connected with "+mConnectedDeviceName);
	    			ReplyChallenge(decryptedMsg.split(MSG_SEP_COLON)[1]);
	    		}
	    		else if(decryptedMsg.startsWith(MSG_CHALLENGE+MSG_SEP_COLON))
	    		{
	    			ReplyChallenge(decryptedMsg.split(MSG_SEP_COLON)[1]);
	    		}
	    		else
	    		{
	    			System.err.println("UNKNOWN MESSAGE FROM SERVER");
	    			Disconnect();
	    		}
	    	}
	    	else
	    	{
	    		 Toast.makeText(this, R.string.not_connected, Toast.LENGTH_SHORT).show();
	    	}
    	}
    	catch(Exception ex)
    	{
    		System.err.println(ex.getMessage());
    		Disconnect();
    	}
    }
    
    //Process session key message
    public void ProcessSessionKey(String sessionkey, String challenge) throws Exception
    {
    	this.sessionKey=sessionkey;
    	long value=Long.parseLong(challenge);
    	long replyvalue=value+1;
    	String reply=encrypt(MSG_SESSION_KEY_REPLY+MSG_SEP_COLON+replyvalue, sessionKey);
    	sendMessage(reply);
    	System.out.println("SESSION_KEY_REPLY : "+reply);
    	
    }
    
    //Reply for the challenge incrementing it by 1
    public void ReplyChallenge(String challengeText) throws Exception
    {
    	long value=Long.parseLong(challengeText);
    	long replyvalue=value+1;
    	String reply=encrypt(MSG_CHALLENGE_REPLY+MSG_SEP_COLON+replyvalue, sessionKey);
    	sendMessage(reply);
    	System.out.println("REPLY : "+reply);
    	Toast.makeText(this, R.string.heart_beat, Toast.LENGTH_SHORT).show();
    }
    
    //Update front end text    
    public void UpdateMessage(String message)
    {
		TextView txtMessage=(TextView) findViewById(R.id.txt_message);
		txtMessage.setText(message);
    }
    
    //Get SHA-256 hash
    private String GetSHAHash(String text)
    {
        String hash = null;
        try
        {
        	MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.update(text.getBytes("iso-8859-1"), 0, text.length());
            byte[] sha1hash = md.digest();
            hash= convertToHex(sha1hash);
            System.out.println("HASH - "+hash);
        }
        catch( NoSuchAlgorithmException e )
        {
            e.printStackTrace();
        }
        catch( UnsupportedEncodingException e )
        {
            e.printStackTrace();
        }
        return hash;
    }
    
    //Byte to String conversion
    private static String convertToHex(byte[] data) {
        StringBuilder buf = new StringBuilder();
        for (byte b : data) {
            int halfbyte = (b >>> 4) & 0x0F;
            int two_halfs = 0;
            do {
                buf.append((0 <= halfbyte) && (halfbyte <= 9) ? (char) ('0' + halfbyte) : (char) ('a' + (halfbyte - 10)));
                halfbyte = b & 0x0F;
            } while (two_halfs++ < 1);
        }
        return buf.toString();
    }
    
    //Get key byte array 256bit
    private byte[] getKeyBytes(String key) throws UnsupportedEncodingException{
        byte[] keyBytes= new byte[32];
        byte[] parameterKeyBytes= key.getBytes(characterEncoding);
        System.arraycopy(parameterKeyBytes, 0, keyBytes, 0, Math.min(parameterKeyBytes.length, keyBytes.length));
        return keyBytes;
    }
    
    //Get Initial Vector byte array 128bit
    private byte[] getIVBytes(String key) throws UnsupportedEncodingException{
        byte[] keyBytes= new byte[16];
        byte[] parameterKeyBytes= key.getBytes(characterEncoding);
        System.arraycopy(parameterKeyBytes, 0, keyBytes, 0, Math.min(parameterKeyBytes.length, keyBytes.length));
        return keyBytes;
    }
 
    //Data decrypting overloaded method
    public  byte[] decrypt(byte[] cipherText, byte[] key, byte [] initialVector) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException
    {
        Cipher cipher = Cipher.getInstance(cipherTransformation);
        SecretKeySpec secretKeySpecy = new SecretKeySpec(key, aesEncryptionAlgorithm);
        IvParameterSpec ivParameterSpec = new IvParameterSpec(initialVector);
        cipher.init(Cipher.DECRYPT_MODE, secretKeySpecy, ivParameterSpec);
        cipherText = cipher.doFinal(cipherText);
        return cipherText;
    }
 
    //Data encrypting overloaded method
    public byte[] encrypt(byte[] plainText, byte[] key, byte [] initialVector) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException
    {
        Cipher cipher = Cipher.getInstance(cipherTransformation);
        SecretKeySpec secretKeySpec = new SecretKeySpec(key, aesEncryptionAlgorithm);
        IvParameterSpec ivParameterSpec = new IvParameterSpec(initialVector);
        cipher.init(Cipher.ENCRYPT_MODE, secretKeySpec, ivParameterSpec);
        plainText = cipher.doFinal(plainText);
        return plainText;
    }
    
    /// <summary>
    /// Encrypts plaintext using AES 128bit key and a Chain Block Cipher and returns a base64 encoded string
    /// </summary>
    /// <param name="plainText">Plain text to encrypt</param>
    /// <param name="key">Secret key</param>
    /// <returns>Base64 encoded string</returns>
    public String encrypt(String plainText, String key) throws UnsupportedEncodingException, InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException{
        byte[] plainTextbytes = plainText.getBytes(characterEncoding);
        byte[] keyBytes = getKeyBytes(key);
        byte[] ivBytes=getIVBytes(key);
        return Base64.encodeToString(encrypt(plainTextbytes,keyBytes, ivBytes), Base64.DEFAULT);
    }
 
    /// <summary>
    /// Decrypts a base64 encoded string using the given key (AES 128bit key and a Chain Block Cipher)
    /// </summary>
    /// <param name="encryptedText">Base64 Encoded String</param>
    /// <param name="key">Secret Key</param>
    /// <returns>Decrypted String</returns>
    public String decrypt(String encryptedText, String key) throws KeyException, GeneralSecurityException, GeneralSecurityException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException, IOException{
        byte[] cipheredBytes = Base64.decode(encryptedText, Base64.DEFAULT);
        byte[] keyBytes = getKeyBytes(key);
        byte[] ivBytes=getIVBytes(key);
        return new String(decrypt(cipheredBytes, keyBytes, ivBytes), characterEncoding);
    }

}
